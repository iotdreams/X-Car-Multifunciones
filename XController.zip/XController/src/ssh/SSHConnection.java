package ssh;
 
import com.jcraft.jsch.JSchException;
import java.io.IOException;

public class SSHConnection {
 
    private static final String USERNAME = "us_prog";
    private static final String HOST = "localhost";
    private static final int PORT = 22;
    private static final String PASSWORD = "programacion";
 
    public static void main(String[] args) throws IllegalAccessException, IOException {
 
        try {
            SSHConnector sshConnector = new SSHConnector();
             
             
            sshConnector.connect(USERNAME, PASSWORD, HOST, PORT);
            String result = sshConnector.executeCommand("ls -l");
            sshConnector.disconnect();
             
            System.out.println(result);
        } catch (JSchException ex) {
            ex.printStackTrace();
             
            System.out.println(ex.getMessage());
        }
    }
}
